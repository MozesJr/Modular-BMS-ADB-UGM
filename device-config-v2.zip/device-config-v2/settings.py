"""Konstanta device.

JANGAN edit file ini untuk setelan per-alat. Buat `settings_local.py` di folder
yang sama dan timpa variabel di sana, supaya tidak hilang saat portal di-update.
Contoh settings_local.py:

    SECRET_SALT = "rahasia-tim-adb"
    DEVICE_KEY = "bmsadb2026!"      # password hotspot + login user
    ADMIN_KEY = "admin-adb-2026"    # password login admin awal
    DEVICE_SERIAL = "001"           # kalau mau nomor seri sendiri
"""
import hashlib
import os

# DEVCFG_MOCK=1 -> jalan di laptop tanpa nmcli/GPIO/OLED (untuk ngoprek tampilan web).
MOCK = os.environ.get("DEVCFG_MOCK") == "1"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get(
    "DEVCFG_DATA", os.path.join(BASE_DIR, "data") if MOCK else "/data/device-config"
)
CONFIG_PATH = os.path.join(DATA_DIR, "config.json")
DEFAULTS_PATH = os.path.join(BASE_DIR, "defaults.json")
STATUS_PATH = os.path.join(DATA_DIR, "status.json") if MOCK else "/run/device-config-status.json"
# Baris OLED titipan program BMS (adb-bms).
APP_DISPLAY_PATH = os.path.join(DATA_DIR, "bms-display.json") if MOCK else "/run/bms-display.json"

SECRET_SALT = "GANTI-DENGAN-STRING-RAHASIA"

# --- Identitas ---
NAME_PREFIX = "BMS-ADB-UGM"     # nama alat & hotspot = BMS-ADB-UGM-<nomor seri>
DEVICE_SERIAL = None            # None = 6 digit terakhir serial Raspberry Pi
DEVICE_KEY = None               # None = diturunkan dari SECRET_SALT + serial
ADMIN_KEY = None                # None = diturunkan dari SECRET_SALT + serial

# --- Jaringan ---
WIFI_IFACE = "wlan0"
AP_CON = "device-ap"
WIFI_CON = "device-wifi"
AP_IP = "192.168.4.1"
WEB_PORT = 8080 if MOCK else 80

SEARCH_NUDGE_S = 30   # saat WiFi putus, minta NetworkManager mencoba lagi tiap sekian detik
AP_IDLE_S = 300       # mode setup tanpa aktivitas di halaman web selama ini -> kembali mencari WiFi

# --- Tombol ---
BUTTON_GPIO = 17      # tombol antara GPIO17 (pin 11) dan GND (pin 9)
HOLD_SETUP_S = 5      # tahan >= 5 dtk  -> mode setup (hotspot)
HOLD_RESET_S = 10     # tahan >= 10 dtk -> factory reset, lalu langsung mode setup

# --- OLED ---
OLED_ENABLED = True
OLED_DRIVER = "ssd1306"
OLED_I2C_PORT = 1
OLED_I2C_ADDR = 0x3C

# Service program BMS, direstart tiap setelan berubah.
APP_SERVICE = "adb-bms"

try:
    from settings_local import *  # noqa: F401,F403
except ImportError:
    pass


def _serial():
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.startswith("Serial"):
                    return line.split(":")[1].strip()
    except OSError:
        pass
    return "0000000000CE78AB" if MOCK else "0000000000000000"


SERIAL = _serial()
DEVICE_SERIAL = str(DEVICE_SERIAL or SERIAL[-6:]).upper()
DEVICE_ID = DEVICE_SERIAL
DEFAULT_NAME = f"{NAME_PREFIX}-{DEVICE_SERIAL}"
AP_SSID = DEFAULT_NAME[:32]
DEVICE_KEY = DEVICE_KEY or hashlib.sha256((SECRET_SALT + SERIAL).encode()).hexdigest()[:8]
ADMIN_KEY = ADMIN_KEY or hashlib.sha256(("admin" + SECRET_SALT + SERIAL).encode()).hexdigest()[:10]
