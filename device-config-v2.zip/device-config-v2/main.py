#!/usr/bin/env python3
"""Device config portal BMS-ADB-UGM: halaman web + watchdog WiFi + tombol + OLED."""
import functools
import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import socket
import subprocess
import threading
import time

from flask import (Flask, abort, flash, jsonify, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

import config_store
import net
import settings as S
from display import Display

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s: %(message)s")
log = logging.getLogger("main")

net_lock = threading.RLock()      # satu operasi jaringan dalam satu waktu
display = Display()
state = {
    "mode": "boot", "ssid": "", "ip": "",
    "ap_since": 0.0,              # kapan hotspot terakhir dinyalakan
    "last_web": 0.0,              # kapan halaman web terakhir dipakai
    "last_error": "",             # hasil percobaan WiFi terakhir
    "busy": "",                   # teks aksi yang sedang berjalan (untuk halaman web)
    "override": None,             # baris OLED sementara (tombol ditahan, dll.)
}
ROLES = {"admin": "Admin", "user": "User"}


def device_name(cfg=None):
    cfg = cfg or config_store.load()
    return cfg.get("device_name") or S.DEFAULT_NAME


# ---------------------------------------------------------------- aksi inti --

def refresh_status():
    st = net.status()
    state.update(st)
    try:
        tmp = S.STATUS_PATH + ".tmp"
        with open(tmp, "w") as f:
            json.dump({**st, "ap_ssid": S.AP_SSID, "device_id": S.DEVICE_ID}, f)
        os.replace(tmp, S.STATUS_PATH)
    except OSError:
        pass
    return st


def enter_ap():
    with net_lock:
        ok, out = net.start_ap()
        state["ap_since"] = time.monotonic()
        if not ok:
            log.error("Hotspot gagal naik: %s", out)
        refresh_status()


def restart_app():
    if S.APP_SERVICE and not S.MOCK:
        subprocess.run(["systemctl", "restart", S.APP_SERVICE], check=False)


def apply_wifi_async(ssid, psk, hidden):
    """Thread terpisah: respons HTTP harus terkirim dulu sebelum hotspot dimatikan."""
    def job():
        time.sleep(2)
        with net_lock:
            state["busy"] = f"Mencoba WiFi {ssid}"
            state["override"] = ["Mencoba WiFi:", ssid, "", "Mohon tunggu..."]
            ok, err = net.apply_wifi(ssid, psk, hidden)
            if ok:
                state["last_error"] = ""
            else:
                log.warning("WiFi '%s' gagal: %s", ssid, err)
                state["last_error"] = f"Gagal terhubung ke {ssid}. Periksa nama dan password WiFi."
                state["override"] = ["WiFi GAGAL:", ssid, "", "Kembali ke", "setelan lama..."]
                if not net.connect_saved():   # rollback ke WiFi lama, kalau ada
                    enter_ap()
                time.sleep(3)
            state["override"] = None
            state["busy"] = ""
            refresh_status()
    threading.Thread(target=job, daemon=True).start()


def factory_reset():
    """Hapus semua setelan lalu LANGSUNG masuk mode setup (tanpa reboot)."""
    log.warning("FACTORY RESET")
    state["busy"] = "Factory reset"
    state["override"] = ["FACTORY RESET", "", "Menghapus setelan..."]
    time.sleep(1)
    config_store.reset()
    with net_lock:
        net.forget_all()
        restart_app()
        enter_ap()
    state["last_error"] = ""
    state["override"] = None
    state["busy"] = ""


# ------------------------------------------------------------ thread latar --

def watchdog_loop():
    net.ensure_retry_forever()
    if not net.wifi_profiles():
        enter_ap()                      # alat baru / habis reset
    last_nudge = 0.0
    while True:
        time.sleep(5)
        with net_lock:
            st = refresh_status()
            now = time.monotonic()
            if st["mode"] == "ap":
                # Mode setup ditinggal (mis. tombol terpencet tidak sengaja):
                # kembali mencari WiFi tersimpan supaya data tidak berhenti terkirim.
                if (net.wifi_profiles()
                        and now - state["ap_since"] > S.AP_IDLE_S
                        and now - state["last_web"] > S.AP_IDLE_S):
                    log.info("Mode setup tidak dipakai, kembali mencari WiFi")
                    net.stop_ap()
                    net.nudge()
                    last_nudge = now
                    refresh_status()
            elif st["mode"] == "offline":
                if not net.wifi_profiles():
                    enter_ap()          # tidak ada WiFi yang bisa dicari
                elif now - last_nudge > S.SEARCH_NUDGE_S:
                    net.nudge()         # terus mencari, TIDAK pindah ke hotspot sendiri
                    last_nudge = now


def button_loop():
    try:
        from gpiozero import Button
        btn = Button(S.BUTTON_GPIO, pull_up=True, bounce_time=0.05)
    except Exception as e:
        log.warning("Tombol tidak aktif: %s", e)
        return
    while True:
        btn.wait_for_press()
        t0, held = time.monotonic(), 0.0
        while btn.is_pressed:
            held = time.monotonic() - t0
            if held >= S.HOLD_RESET_S:
                state["override"] = ["LEPAS SEKARANG:", "", "FACTORY RESET"]
            elif held >= S.HOLD_SETUP_S:
                left = int(S.HOLD_RESET_S - held) + 1
                state["override"] = ["Lepas: MODE SETUP", "", f"Tahan {left} dtk lagi", "untuk factory reset"]
            else:
                left = int(S.HOLD_SETUP_S - held) + 1
                state["override"] = [f"Tahan {left} dtk lagi", "untuk mode setup", "",
                                     f"{S.HOLD_RESET_S} dtk: reset"]
            time.sleep(0.1)
        state["override"] = None
        if held >= S.HOLD_RESET_S:
            factory_reset()
        elif held >= S.HOLD_SETUP_S:
            log.info("Tombol: masuk mode setup")
            enter_ap()


def app_lines():
    """Baris OLED titipan program BMS; None kalau tidak ada atau basi (>30 dtk)."""
    try:
        if time.time() - os.path.getmtime(S.APP_DISPLAY_PATH) > 30:
            return None
        with open(S.APP_DISPLAY_PATH) as f:
            return [str(x) for x in json.load(f)]
    except (OSError, ValueError):
        return None


def oled_lines():
    if state["override"]:
        return state["override"]
    if state["mode"] == "ap":
        return ["== MODE SETUP ==", S.AP_SSID, f"Pass: {S.DEVICE_KEY}",
                "Buka browser:", f"http://{S.AP_IP}"]
    if state["mode"] == "sta":
        lines = app_lines()
        if lines:
            return lines[:4] + [state["ip"]]
        cfg = config_store.load()
        return [device_name(cfg), f"WiFi: {state['ssid']}", state["ip"],
                f"MQTT: {cfg['mqtt']['host'] or '-'}", f"ID: {S.DEVICE_ID}"]
    return ["Mencari WiFi...", device_name(), "",
            f"Tahan tombol {S.HOLD_SETUP_S} dtk", "untuk mode setup"]


def display_loop():
    while True:
        display.show(oled_lines())
        time.sleep(0.3)


# -------------------------------------------------------------------- web --

app = Flask(__name__)
app.secret_key = hashlib.sha256(("flask" + S.SECRET_SALT + S.SERIAL).encode()).digest()
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"


def password_ok(role, pw):
    h = config_store.load().get("auth", {}).get(f"{role}_hash")
    if h:
        return check_password_hash(h, pw)
    default = S.ADMIN_KEY if role == "admin" else S.DEVICE_KEY
    return hmac.compare_digest(pw.encode(), default.encode())


def login_required(fn):
    @functools.wraps(fn)
    def wrapper(*a, **kw):
        if session.get("role") not in ROLES:
            return redirect(url_for("login"))
        return fn(*a, **kw)
    return wrapper


def admin_required(fn):
    @functools.wraps(fn)
    @login_required
    def wrapper(*a, **kw):
        if session.get("role") != "admin":
            abort(403)
        return fn(*a, **kw)
    return wrapper


@app.before_request
def _before():
    state["last_web"] = time.monotonic()
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    if request.method == "POST":
        if not hmac.compare_digest(request.form.get("csrf", ""), session["csrf"]):
            abort(400, "Sesi kedaluwarsa, muat ulang halaman.")


@app.context_processor
def _ctx():
    role = session.get("role")
    return {"csrf": session.get("csrf", ""), "S": S, "state": state,
            "role": role, "role_label": ROLES.get(role, ""), "is_admin": role == "admin"}


@app.errorhandler(404)
def _captive(_e):
    # Di mode setup semua domain diarahkan ke alat, jadi cek koneksi dari HP
    # mendarat di sini dan memunculkan pop-up "Sign in to network".
    if state["mode"] == "ap":
        return redirect(f"http://{S.AP_IP}/", code=302)
    return redirect(url_for("index"))


@app.errorhandler(403)
def _forbidden(_e):
    flash("Bagian itu hanya untuk admin.", "err")
    return redirect(url_for("index"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        role = request.form.get("role", "user")
        if role in ROLES and password_ok(role, request.form.get("password", "")):
            session["role"] = role
            return redirect(url_for("index"))
        time.sleep(1.5)                 # perlambat tebak-tebakan
        flash("Password salah untuk peran " + ROLES.get(role, "User") + ".", "err")
        return render_template("login.html", name=device_name(), chosen=role), 401
    return render_template("login.html", name=device_name(), chosen="user")


@app.route("/logout", methods=["POST"])
def logout():
    session.pop("role", None)
    return redirect(url_for("login"))


def status_payload():
    cfg = config_store.load()
    return {"mode": state["mode"], "ssid": state["ssid"], "ip": state["ip"],
            "name": device_name(cfg), "mqtt": cfg["mqtt"]["host"],
            "busy": state["busy"], "error": state["last_error"],
            "oled": [str(l)[:21] for l in oled_lines()[:5]]}


@app.route("/")
@login_required
def index():
    cfg = config_store.load()
    auth = cfg.get("auth", {})
    return render_template("index.html", cfg=cfg, name=device_name(cfg),
                           nets=net.scan(rescan=False), st=status_payload(),
                           default_pw={"admin": not auth.get("admin_hash"),
                                       "user": not auth.get("user_hash")})


@app.route("/api/status")
@login_required
def api_status():
    return jsonify(status_payload())


@app.route("/scan")
@login_required
def scan():
    # Di mode hotspot radio sedang dipakai, jadi hanya bisa kirim hasil scan terakhir.
    with net_lock:
        return jsonify(net.scan(rescan=state["mode"] != "ap"))


@app.route("/wifi", methods=["POST"])
@login_required
def wifi():
    ssid = request.form.get("ssid", "").strip()
    psk = request.form.get("psk", "")
    if not ssid or len(ssid.encode()) > 32:
        flash("Isi nama WiFi (maksimal 32 karakter).", "err")
    elif psk and not 8 <= len(psk) <= 63:
        flash("Password WiFi harus 8–63 karakter. Kosongkan untuk WiFi tanpa password.", "err")
    else:
        apply_wifi_async(ssid, psk, bool(request.form.get("hidden")))
        return render_template("wait.html", kind="wifi", ssid=ssid, name=device_name())
    return redirect(url_for("index") + "#wifi")


@app.route("/mqtt", methods=["POST"])
@admin_required
def mqtt():
    f = request.form
    host = f.get("host", "").strip().split("://")[-1].split("/")[0]
    try:
        port = int(f.get("port", ""))
        assert 1 <= port <= 65535
    except (ValueError, AssertionError):
        flash("Port MQTT harus angka 1–65535.", "err")
        return redirect(url_for("index") + "#mqtt")
    if not host:
        flash("Isi host broker MQTT, contoh: gamabms.tech", "err")
        return redirect(url_for("index") + "#mqtt")

    if state["mode"] == "sta" and not f.get("force"):
        try:
            socket.create_connection((host, port), timeout=6).close()
        except OSError as e:
            flash(f"Broker {host}:{port} tidak bisa dihubungi ({e}). Setelan belum disimpan. "
                  "Centang 'Simpan walau broker tidak terjangkau' kalau yakin.", "err")
            return redirect(url_for("index") + "#mqtt")

    cfg = config_store.load()
    m = cfg["mqtt"]
    m.update(host=host, port=port, username=f.get("username", "").strip(),
             base_topic=f.get("base_topic", "").strip().strip("/"),
             client_id=f.get("client_id", "").strip(), tls=bool(f.get("tls")))
    if f.get("password"):
        m["password"] = f["password"]
    if f.get("clear_password"):
        m["password"] = ""
    config_store.save(cfg)
    restart_app()
    flash("Setelan MQTT disimpan." + ("" if state["mode"] == "sta"
          else " Belum dites karena alat sedang tidak terhubung internet."), "ok")
    return redirect(url_for("index") + "#mqtt")


NAME_RE = re.compile(r"^[A-Za-z0-9 ._-]{1,32}$")


@app.route("/device", methods=["POST"])
@admin_required
def device():
    name = request.form.get("device_name", "").strip()
    try:
        interval = int(request.form.get("interval_s", ""))
        assert 1 <= interval <= 86400
    except (ValueError, AssertionError):
        flash("Interval kirim data harus angka 1–86400 detik.", "err")
        return redirect(url_for("index") + "#device")
    if name and not NAME_RE.match(name):
        flash("Nama alat maksimal 32 karakter: huruf, angka, spasi, titik, - atau _.", "err")
        return redirect(url_for("index") + "#device")
    cfg = config_store.load()
    cfg["device_name"] = "" if name == S.DEFAULT_NAME else name
    cfg["app"]["interval_s"] = interval
    config_store.save(cfg)
    restart_app()
    flash("Nama dan interval alat disimpan.", "ok")
    return redirect(url_for("index") + "#device")


@app.route("/password", methods=["POST"])
@admin_required
def password():
    target = request.form.get("target")
    new = request.form.get("new", "")
    if target not in ROLES:
        abort(400)
    if not password_ok("admin", request.form.get("current", "")):
        flash("Password admin saat ini salah.", "err")
    elif len(new) < 8 or new != request.form.get("new2", ""):
        flash("Password baru minimal 8 karakter dan kedua isian harus sama.", "err")
    else:
        cfg = config_store.load()
        cfg.setdefault("auth", {})[f"{target}_hash"] = generate_password_hash(
            new, method="pbkdf2:sha256:60000")
        config_store.save(cfg)
        flash(f"Password {ROLES[target]} diganti.", "ok")
    return redirect(url_for("index") + "#security")


@app.route("/reset", methods=["POST"])
@login_required
def reset():
    if request.form.get("confirm", "").strip().upper() != "RESET":
        flash("Ketik RESET untuk konfirmasi factory reset.", "err")
        return redirect(url_for("index") + "#reset")
    session.clear()
    threading.Thread(target=lambda: (time.sleep(2), factory_reset()), daemon=True).start()
    return render_template("wait.html", kind="reset", ssid=None, name=device_name())


def main():
    os.makedirs(S.DATA_DIR, exist_ok=True)
    if S.SECRET_SALT.startswith("GANTI"):
        log.warning("SECRET_SALT masih bawaan. Atur di settings_local.py sebelum produksi!")
    log.info("Alat %s | hotspot %s | password user/hotspot %s | password admin %s",
             device_name(), S.AP_SSID, S.DEVICE_KEY, S.ADMIN_KEY)
    if S.MOCK and os.environ.get("DEVCFG_MOCK_ONLINE") == "1":
        net.mock_seed_wifi()
    for fn in (watchdog_loop, button_loop, display_loop):
        threading.Thread(target=fn, daemon=True, name=fn.__name__).start()
    app.run(host="0.0.0.0", port=S.WEB_PORT, threaded=True, use_reloader=False)


if __name__ == "__main__":
    main()
