# device-config v2 (BMS-ADB-UGM)

Portal setelan alat BMS berbasis Raspberry Pi Zero W.

## Perilaku

| Kondisi | Yang terjadi |
|---|---|
| Alat baru / habis factory reset | Langsung mode setup: hotspot `BMS-ADB-UGM-<seri>`, password tampil di OLED. |
| WiFi putus | Alat **terus mencari** WiFi tersimpan. Tidak pindah ke hotspot sendiri. |
| Tombol ditahan 5 detik | Mode setup (hotspot). |
| Tombol ditahan 10 detik | Factory reset, lalu langsung mode setup (tanpa reboot). |
| Mode setup tidak dipakai 5 menit | Kalau ada WiFi tersimpan, kembali mencari WiFi (mis. tombol terpencet tidak sengaja). |
| Ganti WiFi gagal | Kembali ke WiFi lama; kalau tidak ada, hotspot muncul lagi. |

## Peran login

| | User | Admin |
|---|---|---|
| Atur WiFi | ya | ya |
| Factory reset | ya | ya |
| MQTT, nama alat, interval | - | ya |
| Ganti password user/admin | - | ya |

Password awal: user = password hotspot (tampil di OLED), admin = `ADMIN_KEY`
(tercetak di log saat start: `journalctl -u device-config | grep admin`).

## Setelan per alat

Jangan edit `settings.py`. Buat `settings_local.py` di folder yang sama:

    SECRET_SALT = "rahasia-tim-adb"
    DEVICE_KEY = "bmsadb2026!"
    ADMIN_KEY = "admin-adb-2026"
    DEVICE_SERIAL = "001"     # opsional, default 6 digit terakhir serial Pi

## Coba di laptop

    DEVCFG_MOCK=1 python3 main.py                       # alat baru (mode setup)
    DEVCFG_MOCK=1 DEVCFG_MOCK_ONLINE=1 python3 main.py  # alat sudah online

Buka http://localhost:8080, password tercetak di log.
